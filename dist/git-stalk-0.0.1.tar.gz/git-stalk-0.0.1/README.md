# git-stalk-cli

A command line interface for checking your/peer's contribution today.
